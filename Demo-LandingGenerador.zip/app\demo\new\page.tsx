"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, Loader2, Wand2, LayoutTemplate, Globe2 } from 'lucide-react';

export default function NewLandingDemo() {
  const router = useRouter();
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  const steps = [
    "Iniciando motores de IA...",
    "Analizando destino y extrayendo puntos clave...",
    "Redactando copywriting persuasivo de alto impacto...",
    "Estructurando formato JSON para la plantilla...",
    "Aplicando estilos de Aventura y optimizando assets..."
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    
    let step = 0;
    const interval = setInterval(() => {
      step++;
      setLoadingStep(step);
      if (step >= steps.length) {
        clearInterval(interval);
        router.push('/demo/preview');
      }
    }, 1800);
  };

  if (isGenerating) {
    return (
      <div className="flex flex-col items-center justify-center h-[75vh] animate-in fade-in zoom-in-95 duration-500">
        {/* Glow effect background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-500/20 blur-[100px] rounded-full pointer-events-none" />
        
        <div className="relative">
          <div className="absolute inset-0 bg-blue-500 blur-2xl opacity-20 animate-pulse rounded-full" />
          <div className="w-28 h-28 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-3xl flex items-center justify-center mb-10 relative z-10 shadow-2xl shadow-blue-500/40">
            <Wand2 className="text-white absolute animate-ping opacity-50" size={50} />
            <Wand2 className="text-white relative z-10" size={50} />
          </div>
        </div>

        <h2 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-800 to-slate-500 mb-4 tracking-tight text-center">
          La Magia está Ocurriendo
        </h2>
        
        <div className="flex items-center gap-3 px-6 py-3 bg-white/60 backdrop-blur-md rounded-full shadow-sm border border-slate-200">
          <Loader2 size={18} className="animate-spin text-blue-600" />
          <p className="text-slate-700 font-semibold">
            {steps[Math.min(loadingStep, steps.length - 1)]}
          </p>
        </div>
        
        {/* Progress bar */}
        <div className="w-80 h-3 bg-slate-200/50 rounded-full mt-10 overflow-hidden relative backdrop-blur-sm border border-slate-200">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-500 opacity-20 animate-pulse" />
          <div 
            className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-1000 ease-out rounded-full relative shadow-[0_0_10px_rgba(79,70,229,0.5)]"
            style={{ width: `${Math.min(((loadingStep + 1) / steps.length) * 100, 100)}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-extrabold text-slate-800 tracking-tight mb-3">Crear Nueva Landing</h1>
        <p className="text-lg text-slate-500">Deja que nuestra IA genere el contenido perfecto en segundos.</p>
      </div>

      <div className="bg-white rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-slate-100/50 p-10 relative overflow-hidden">
        {/* Decorative corner */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-50 rounded-full blur-3xl opacity-50" />
        
        <div className="space-y-8 relative z-10">
          <div className="group">
            <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wider">Nombre del Proyecto</label>
            <input 
              type="text" 
              defaultValue="Tour Salkantay Trek Experiencia" 
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white outline-none transition-all font-medium text-slate-800 text-lg"
            />
          </div>

          <div className="group">
            <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wider">¿Qué vamos a vender?</label>
            <div className="relative">
              <textarea 
                rows={5}
                defaultValue="Un trekking de aventura hacia Machu Picchu por el nevado Salkantay. 5 días y 4 noches. Público objetivo: jóvenes aventureros. Incluye comidas, guía experto y tren de retorno. Tono épico y motivador."
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white outline-none resize-none transition-all font-medium text-slate-700 leading-relaxed"
              />
              <div className="absolute bottom-4 right-4 text-xs font-bold text-slate-400 bg-white px-2 py-1 rounded-md shadow-sm border border-slate-100">
                Contexto IA Activo
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
            <div>
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3 uppercase tracking-wider">
                <LayoutTemplate size={16} className="text-blue-500" /> Plantilla Visual
              </label>
              <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none font-medium text-slate-700 cursor-pointer hover:bg-slate-100 transition-colors">
                <option>Aventura Premium (Recomendado)</option>
                <option>Minimalista de Lujo</option>
                <option>Cultural Clásico</option>
              </select>
            </div>
            <div>
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-3 uppercase tracking-wider">
                <Globe2 size={16} className="text-emerald-500" /> Idioma
              </label>
              <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none font-medium text-slate-700 cursor-pointer hover:bg-slate-100 transition-colors">
                <option>Español (Latam)</option>
                <option>Inglés (USA)</option>
                <option>Portugués (Brasil)</option>
              </select>
            </div>
          </div>

          <div className="pt-10 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-6 mt-4">
            <p className="text-sm font-medium text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Motor OpenAI listo
            </p>
            <div className="flex gap-4 w-full sm:w-auto">
              <button className="px-8 py-4 text-slate-500 font-bold hover:bg-slate-100 rounded-2xl transition-colors w-full sm:w-auto">
                Cancelar
              </button>
              <button 
                onClick={handleGenerate}
                className="group relative bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-4 rounded-2xl font-bold transition-all shadow-[0_0_40px_rgba(79,70,229,0.3)] hover:shadow-[0_0_60px_rgba(79,70,229,0.5)] hover:scale-[1.02] flex items-center justify-center gap-3 w-full sm:w-auto overflow-hidden"
              >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out" />
                <Sparkles size={20} className="relative z-10 group-hover:animate-pulse" />
                <span className="relative z-10">Generar con IA Mágica</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
