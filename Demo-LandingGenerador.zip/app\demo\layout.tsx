import React from 'react';
import { LayoutDashboard, FilePlus2, Settings, LogOut, Mountain, Sparkles, Bell } from 'lucide-react';
import Link from 'next/link';

export default function DemoLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-[#F8FAFC]">
      {/* Premium Sidebar */}
      <aside className="w-72 bg-[#0B1120] text-slate-300 flex flex-col border-r border-slate-800/50 shadow-2xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 left-0 w-full h-64 bg-blue-600/10 blur-[100px] pointer-events-none" />
        
        <div className="p-8 relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Mountain size={20} />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-white tracking-tight">Cusco Creativos</h1>
              <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">Internal System</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-6 py-4 space-y-3 relative z-10">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 px-2">Menu Principal</p>
          
          <Link href="/demo" className="group flex items-center gap-3 px-4 py-3.5 bg-gradient-to-r from-blue-600/20 to-indigo-600/10 text-blue-400 rounded-2xl font-bold transition-all border border-blue-500/20 hover:border-blue-500/40 relative overflow-hidden">
            <div className="absolute inset-0 w-1 bg-blue-500 left-0 top-0 bottom-0" />
            <LayoutDashboard size={20} className="group-hover:scale-110 transition-transform" />
            Panel Principal
          </Link>
          
          <Link href="/demo/new" className="group flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 rounded-2xl font-medium text-slate-400 hover:text-white transition-all">
            <FilePlus2 size={20} className="group-hover:text-emerald-400 transition-colors" />
            Nueva Landing
          </Link>

          <a href="#" className="group flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 rounded-2xl font-medium text-slate-400 hover:text-white transition-all">
            <Settings size={20} />
            Configuración
          </a>
        </nav>

        {/* AI Quota card */}
        <div className="p-6 relative z-10">
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-4 border border-slate-700/50 relative overflow-hidden">
            <Sparkles size={100} className="absolute -right-6 -top-6 text-white/5" />
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Cuota de IA</p>
            <div className="w-full bg-slate-950 rounded-full h-1.5 mb-2">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-1.5 rounded-full" style={{ width: '45%' }}></div>
            </div>
            <p className="text-sm font-medium text-white">45 / 100 <span className="text-slate-500">créditos</span></p>
          </div>
        </div>

        <div className="p-6 border-t border-slate-800/50 relative z-10">
          <a href="/" className="flex items-center gap-3 px-4 py-3 hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 rounded-2xl transition-colors font-medium">
            <LogOut size={18} />
            Cerrar Sesión
          </a>
        </div>
      </aside>
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white/80 backdrop-blur-xl h-20 border-b border-slate-200/50 flex items-center px-10 justify-between shrink-0 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border border-slate-200">
              <span className="text-xs font-bold">⌘K</span>
            </div>
            <span className="text-sm font-medium text-slate-400">Buscar proyectos...</span>
          </div>
          
          <div className="flex items-center gap-6">
            <button className="relative text-slate-400 hover:text-slate-600 transition-colors">
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-px bg-slate-200"></div>
            <div className="flex items-center gap-3 bg-slate-50 pl-2 pr-4 py-1.5 rounded-full border border-slate-100 cursor-pointer hover:bg-slate-100 transition-colors">
              <div className="w-8 h-8 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-inner">
                AD
              </div>
              <span className="text-sm font-bold text-slate-700">Admin User</span>
            </div>
          </div>
        </header>
        <div className="p-10 flex-1 overflow-auto bg-[#F8FAFC]">
          {children}
        </div>
      </main>
    </div>
  );
}
